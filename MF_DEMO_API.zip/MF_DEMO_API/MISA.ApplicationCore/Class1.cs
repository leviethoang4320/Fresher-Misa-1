﻿using System;

namespace MISA.Service
{
    public class Class1
    {
    }
}
