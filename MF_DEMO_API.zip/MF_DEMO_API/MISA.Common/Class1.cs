﻿using System;

namespace MISA.Common
{
    public class Class1
    {
    }
}
