<template>
     <div class="header">
        <div class="header-left mg-left-20px" >
            <Span style="font-size:18px">Cửa hàng</Span>
        </div>

        <div class="header-right">
            <div class="store-main">
                <select style="margin-top: 20px; margin-right: 10px;">
                    <option>CANIFA-130 Xuân Thủy</option>
                </select>
            </div>
            <div class="account-info">
                <div class="account-avatar"></div>
                <div class="account-name">lvhoang</div>            
            </div>
           
            <div class="header-item-call"></div>
            <div class="header-item-notify"></div>
            
        </div>
        
    </div>
</template>