<template>
  <v-row justify="center">
    <v-dialog 
      v-model="dialog"
      persistent
      max-width="600px"
      
    >
      
      <v-card >
        <v-card-title style="background-color: #f1f1f1">
          <span class="headline">{{status}}</span>
          <span class="icon-close"  @click="dlg_close()"></span>
        </v-card-title>
        <v-card-text>
          <v-container>
            <div class="m-row  ">
                <div class="m-col m-flex">
                    <div class="m-label mg-top-5px">Mã cửa hàng (<span class="label-required">*</span>)</div>
                    <div class="m-control input mg-left-10px " ><input id="myinput" required class="input-required" type="text" autofocus/></div>
                </div>
                
            </div>
            <div class="m-row  ">
                
                <div class="m-flex" >
                    <div class="m-label mg-top-5px">Tên cửa hàng (<span class="label-required">*</span>)</div>
                    <div class="m-control input mg-left-10px" >
                        <input  class="input-required" type="text" required />
                    </div>
                </div>
            </div>
            <div class="m-row  ">
                
                <div class="m-flex" >
                    <div class="m-label mg-top-5px">Địa chỉ (<span class="label-required">*</span>)</div>
                    <div class="m-control input mg-left-10px" >
                        <input  class="input-required" type="text" required />
                    </div>
                </div>
            </div>
          </v-container>
          <small>*indicates required field</small>
        </v-card-text>
        <v-card-actions >
          <v-spacer></v-spacer>
          <v-btn
            color="blue darken-1"
            text
            @click="dlg_close()"
          >
            Close
          </v-btn>
          <v-btn
            color="blue darken-1"
            text
            @click="dlg_close()"
          >
            Save
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </v-row>
</template>

<script>
  export default {
    props:{
        dialogOpen: Boolean,
        status: String
    },
    data: () => ({
      dialog :  false,
    }),
    mounted() {
      this.dialog = this.dialogOpen;
      this.onFocus();
    },
    methods: {
        dlg_close(){
            this.dialog = false;
            this.$emit('close');
        },
        onFocus(){
          this.$refs.code.focus();
        }
        
    },
  }
</script>
<style scoped>
  .input{
    width: 70%;
    position:absolute;
    right: 20px;
  }
  
</style>