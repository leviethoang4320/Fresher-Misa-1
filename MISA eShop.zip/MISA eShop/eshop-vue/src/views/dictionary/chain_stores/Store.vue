<template>
    <div class="content-body">
        <div class="header-content">
          <div class="cnt-item" @click="dlg_openAdd()">
            <div class="ctn-item-icon icon-add mg-left-10px"></div>
            <div class="ctn-item-text mg-left-10px" >Thêm mới</div>
          </div>
          <div class="cnt-item">
            <div class="ctn-item-icon icon-copy mg-left-10px"></div>
            <div class="ctn-item-text mg-left-10px">Nhân bản</div>
          </div>
          <div class="cnt-item" @click="dlg_openEdit()">
            <div class="ctn-item-icon icon-edit mg-left-10px"></div>
            <div class="ctn-item-text mg-left-10px">Sửa</div>
          </div>
          <div class="cnt-item">
            <div class="ctn-item-icon icon-del mg-left-10px"></div>
            <div class="ctn-item-text mg-left-10px">Xóa</div>
          </div>
          <div class="cnt-item">
            <div class="ctn-item-icon icon-load mg-left-10px"></div>
            <div class="ctn-item-text mg-left-10px">Nạp</div>
          </div>
          
        </div>
        
        <div class="grid ">

            <table  class="table" cellspacing="0" cellpadding="0" border="0"  >

                <thead class="table-head">
                    <tr class="table-row head first">
                        <th colspan="1" rowspan="1" width= "10%" >
                            Mã cửa hàng
                        </th>
                        <th colspan="1" rowspan="1" width= "25%" >
                            Tên cửa hàng
                        </th>
                        <th colspan="1" rowspan="1"  width= "35%">
                            Địa chỉ
                        </th>
                        <th colspan="1" rowspan="1"  width= "15%">
                            Số điện thoại
                        </th>
                        <th colspan="1" rowspan="1"  width= "15%">
                            Trạng thái hoạt động
                        </th>
                        
                    </tr>
                    <tr class="table-row head filter">
                        <th colspan="1" rowspan="1" v-for="(item,index) in store" :key="index" >
                            <table cellspacing="1px" cellpadding="1px" border="0" v-if="item.key!='Status'">
                                <tr  >
                                    <td style="width: 40px; text-align: center;" >*</td>
                                    <td></td>
                                </tr>
                                
                            </table>
                            <select v-else name="" id="" style="border:none;">
                                <option value="">Đang hoạt động</option>
                                <option value="">Không hoạt động</option>
                            </select>
                        </th>
                        
                        
                    </tr>
                    
                </thead>
                <tbody>
                    <tr class="table-row table-body" v-for="(data,index) in resData" :key="index" >
                        <td rowspan="1" colspan="1" v-for="(item,index) in store" :key="index"  >
                            <div class="cell" >
                                {{data[item.key]}}
                            </div>
                        </td>
                        
                    </tr>
                </tbody>

            </table>



        </div> 

        <div class="paging-bar">
            <div class="paging-option">
                <div class="btn-select-page  ">
                    <div class="m-btn-first-page"></div>
                </div>
                <div class="btn-select-page ">
                    <div class="m-btn-prev-page"></div>
                </div>
                <div>Trang</div>
                <div class="page-now " style="border: 1px solid rgb(133, 132, 132); height:20px; width:40px; padding-left:5px">1</div>
                <div >trên 1</div>
                <div class="btn-select-page ">
                    <div class="m-btn-next-page"></div>
                </div>
                <div class="btn-select-page ">
                    <div class="m-btn-last-page"></div>
                </div>
                <div class="btn-select-page ">
                    <div class="reload"></div>
                </div>
                <div>
                    <select name="" id="" style="height: 25px;">
                        <option value="">20</option>
                    </select>
                </div>
            </div>
            <div class="paging-info">
                
                <div>Hiển thị 1 - 20 trên 20 kết quả</div>
                
            </div>
            
        </div>
        <div data-app>
         <DialogStore v-if="dialogOpen" @close="close()" :dialogOpen = "dialogOpen" :status = "status" /> 
         </div>
    </div> 
</template>

<script>
import DialogStore from './DialogStore'
import axios from 'axios'
export default {
    components:{
        DialogStore
    },
    data() {
        return {
            resData:Array,
            store:[
                {
                    key: "StoreCode" ,
                    title : "Mã cửa hàng"
                },
                {
                    key: "StoreName",
                    title : "Tên cửa hàng"
                },
                {
                    key: "Address",
                    title : "Địa chỉ"
                },
                {
                    key: "PhoneNumber",
                    title : "Số điện thoại"
                },
                {
                    key: "Status",
                    title : "Trạng thái hoạt động"
                },
            ],

            // resData:[
            //     {
            //         StoreCode: "130XT",
            //         StoreName: "CANIFA - 130 XUÂN THỦY",
            //         Address: "130 Xuân Thủy",
            //         PhoneNumber: "0943513595",
            //         Status: "Đang hoạt động"
            //     },
            //     {
            //         StoreCode: "123BT",
            //         StoreName: "CANIFA - 123 BÀ TRIỆU",
            //         Address: "123 Bà Triệu",
            //         PhoneNumber: "0943513595",
            //         Status: "Đang hoạt động"
            //     },
            //     {
            //         StoreCode: "234TH",
            //         StoreName: "CANIFA - 234 TÔ HIỆU",
            //         Address: "234 Tô Hiệu",
            //         PhoneNumber: "0943513595",
            //         Status: "Đang hoạt động"
            //     },
            //     {
            //         StoreCode: "266HBT",
            //         StoreName: "CANIFA - 266 HAI BÀ TRƯNG",
            //         Address: "266 Hai Bà Trưng",
            //         PhoneNumber: "0943513595",
            //         Status: "Đang hoạt động"
            //     },
            //     {
            //         StoreCode: "199TQH",
            //         StoreName: "CANIFA - 199 TRẦN QUỐC HOÀN",
            //         Address: "199 Trần Quốc Hoàn",
            //         PhoneNumber: "0943513595",
            //         Status: "Đang hoạt động"
            //     },
            //     {
            //         StoreCode: "300TV",
            //         StoreName: "CANIFA - 300 TRẦN VỸ",
            //         Address: "300 Trần Vỹ",
            //         PhoneNumber: "0943513595",
            //         Status: "Đang hoạt động"
            //     },
                
            // ],
            dialogOpen: false,
            status: String
        }
    },
     mounted() {
         axios
      .get('https://localhost:44384/api/Stores')
      .then(response => {
          this.resData = response.data;
          
         
      })
      .catch(error => console.log(error));
    },
     methods: {
    //     load(){
            
    //     },
    //     edit(id){
    //         this.employeeId = id;
    //         this.dialogOpen = true;
    //         console.log(this.employeeId)
    //     },
    
    
        close(){
            this.dialogOpen = false;
            console.log('123')
        },
        dlg_openAdd(){
            this.dialogOpen = !this.dialogOpen;
            this.status = "Thêm mới cửa hàng"
        },
        dlg_openEdit(){
            this.dialogOpen = !this.dialogOpen;
            this.status = "Sửa thông tin cửa hàng"
        }
     },
//     // filters: {
        
//     // }
 }
 </script>

 <style scoped >

.content-body {
    background-color: #ffffff;
    height: calc(100% - 10px);
}

  .header-content{
    background-color: #2b3173;
  }
  .ctn-item-text{
    color: white ;

  }
  .cnt-item{
    display: flex;
    border-right: 1px solid #1e235a;
    height: 100%;
    align-items: center;
    padding-right: 5px;
    cursor: pointer;
  }

</style>
